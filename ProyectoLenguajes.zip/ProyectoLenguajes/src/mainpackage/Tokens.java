package mainpackage;

/**
 *
 * @author danno
 */
public enum Tokens {
    Entero,
    Condicional,
    Else,
    While,
    Igual,
    Suma,
    Resta,
    Multiplicacion,
    Division,
    ERROR,
    Identificador,
    Numero,
    CorcheteDeApertura,
    CorcheteDeCerradura
}
