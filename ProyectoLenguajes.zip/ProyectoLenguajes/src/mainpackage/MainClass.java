package mainpackage;

import java.io.File;

public class MainClass {
    public static void main(String[] args) {
        //Ruta del Lexer.flex
        String route="C:/Users/danno/OneDrive/Documents/NetBeansProjects/ProyectoLenguajes/src/mainpackage/Lexer.flex";
        generateLexer(route);
    }
public static void generateLexer(String route){
        File archive=new File(route);
        JFlex.Main.generate(archive);
    }    
}
